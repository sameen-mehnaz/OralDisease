import tensorflow as tf
from tensorflow.keras.models import load_model
import numpy as np
import os
from tensorflow.keras.preprocessing import image
from sklearn.preprocessing import LabelEncoder  # Import LabelEncoder
from tensorflow.keras.utils import to_categorical  # Import to_categorical for one-hot encoding

# Load the trained model
model = load_model('model_code/oral_disease_model.keras') # Replace with the correct model path

# Set up the path to the test images
test_dir = 'C:/OralDisease/TEST'  # Update this with the correct path

# Function to load and preprocess the test images
def load_test_data(test_dir):
    test_images = []
    test_labels = []

    # Loop through subdirectories (Caries and Gingivitis)
    for label in ['Caries', 'Gingivitis']:
        label_dir = os.path.join(test_dir, label)
        for filename in os.listdir(label_dir):
            if filename.endswith('.jpg') or filename.endswith('.png'):
                img_path = os.path.join(label_dir, filename)
                img = image.load_img(img_path, target_size=(150, 150))  # Resize to match model input
                img_array = image.img_to_array(img)  # Convert image to array
                img_array = img_array / 255.0  # Normalize the image
                test_images.append(img_array)
                test_labels.append(label)  # Append the label (Caries or Gingivitis)

    return np.array(test_images), np.array(test_labels)

# Load the test data
X_test, y_test = load_test_data(test_dir)

# Encode labels to numeric values using LabelEncoder
label_encoder = LabelEncoder()
y_test_encoded = label_encoder.fit_transform(y_test)  # This will convert 'Caries' to 0 and 'Gingivitis' to 1

# One-hot encode the labels
y_test_one_hot = to_categorical(y_test_encoded, num_classes=2)  # Convert to one-hot encoding

# Make predictions on the test data
predictions = model.predict(X_test)

# Evaluate the model on the test data
loss, accuracy = model.evaluate(X_test, y_test_one_hot)  # Use one-hot encoded labels for evaluation
print(f"Test Loss: {loss}")
print(f"Test Accuracy: {accuracy}")

# Displaying some predictions
for i in range(5):  # Display first 5 predictions
    predicted_class = np.argmax(predictions[i])  # Get the predicted class (0 or 1)
    true_class = y_test_one_hot[i]  # Get the true class (one-hot encoded)
    print(f"Prediction: {predicted_class} ({label_encoder.inverse_transform([predicted_class])[0]}), True label: {np.argmax(true_class)} ({label_encoder.inverse_transform([np.argmax(true_class)])[0]})")
def test_model():
    # Your model testing code here
    print("Model testing is complete.")
