import os
from tensorflow.keras.preprocessing import image
import numpy as np

def preprocess_images(image_folder, target_size=(150, 150)):
    images = []
    labels = []

    # Iterate through the subfolders (Caries, Gingivitis) inside each folder
    for label in os.listdir(image_folder):  # 'TRAIN' or 'TEST' folder
        class_folder = os.path.join(image_folder, label)

        # Check if it's a valid folder (Caries, Gingivitis)
        if os.path.isdir(class_folder):
            for img_name in os.listdir(class_folder):
                img_path = os.path.join(class_folder, img_name)

                # Check if the file is an image
                if img_path.endswith(('.jpg', '.jpeg', '.png')):
                    # Load and preprocess image
                    img = image.load_img(img_path, target_size=target_size)
                    img_array = image.img_to_array(img) / 255.0  # Normalize the image
                    images.append(img_array)
                    labels.append(label)

    images = np.array(images)
    labels = np.array(labels)

    return images, labels

def preprocess_data():
    # Preprocess the images for training and testing
    train_folder = 'C:/OralDisease/TRAIN'
    test_folder = 'C:/OralDisease/TEST'

    # Preprocess training images and labels
    train_images, train_labels = preprocess_images(train_folder)
    print("Training Images Shape:", train_images.shape)
    print("Training Labels Shape:", train_labels.shape)

    # Preprocess testing images and labels
    test_images, test_labels = preprocess_images(test_folder)
    print("Test Images Shape:", test_images.shape)
    print("Test Labels Shape:", test_labels.shape)

    # Optionally, return the preprocessed data for use in training/testing
    return train_images, train_labels, test_images, test_labels

# If you want to test the preprocessing directly from this script
if __name__ == "__main__":
    preprocess_data()
