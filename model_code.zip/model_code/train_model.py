import os
import numpy as np
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.utils import to_categorical

# Function to load images and labels
def load_data(data_dir):
    images = []
    labels = []
    # Define the class labels
    class_labels = ['Caries', 'Gingivitis']
    
    for label in class_labels:
        label_dir = os.path.join(data_dir, label)
        for filename in os.listdir(label_dir):
            img_path = os.path.join(label_dir, filename)
            img = image.load_img(img_path, target_size=(150, 150))  # Resize images
            img_array = image.img_to_array(img) / 255.0  # Normalize images
            images.append(img_array)
            labels.append(class_labels.index(label))  # Assign the label index (0 or 1)
    
    return np.array(images), np.array(labels)

# Set up the paths for training and testing
train_dir = 'C:/OralDisease/TRAIN'  # Update with your actual path
test_dir = 'C:/OralDisease/TEST'  # Update with your actual path

# Load the training and testing data
X_train, y_train = load_data(train_dir)
X_test, y_test = load_data(test_dir)

# One-hot encode the labels
y_train = to_categorical(y_train, num_classes=2)
y_test = to_categorical(y_test, num_classes=2)

# Define the model architecture
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(150, 150, 3)),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    Flatten(),
    Dense(64, activation='relu'),
    Dense(2, activation='softmax')  # 2 output classes: Caries and Gingivitis
])

# Compile the model
model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, epochs=10, validation_data=(X_test, y_test))

# Save the trained model
model.save('oral_disease_model.keras')


def train_model():
    # Your model training code here
    print("Model training is complete.")
